import React from "react";
import Card from "./Card";
import Daftar from "./Daftar";
import Footer from "./Footer";
import Header from "./Header";
import { useState } from "react";
import { useEffect } from "react";
import { apiHandler } from "../Api/apiHandler";
import Services from "./Service";


export default function Main() {
  const [input, setInput] = useState("");
  const [data, setData] = useState();
  useEffect(() => {
    apiHandler.get().then((result) => setData(result));
  }, []);

  if (!data) return "loading...";

  const deleteHandling = async (id) => {
    setData(data.filter((data) => data.id != id));
    await apiHandler.delete(id);
  };
  console.log(data?.filter((i) => i.nama.toLowerCase().indexOf(input) > -1))
  return (
    <>
      <Header />
      <div className="buku" id="buku">
        <div className="container">
          <center>
            <input placeholder="Cari Buku.." className="search" onChange={(e) => setInput(e.target.value)} type="text" />
          </center>
          <div className="box-buku">
            {data?.filter((i) => i.judul.toLowerCase().indexOf(input) > -1).map((item, i) => (
              <Card key={i} {...{ item, deleteHandling }} setAllData={setData} allData={data} />
            ))}
          </div>
        </div>
      </div>
      <Services />
      <Daftar />
      <Footer />
    </>
  );
}