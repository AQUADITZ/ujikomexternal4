import React from "react";

export default function Footer() {
  return (
    <div className="footer">
      <div className="container">
        <div className="box-footer">
          <div className="box">
            <h2>DIGITAL LIBRARY</h2>
            <h5>
              TANGERANG SELATAN
            </h5>
          </div>
         <h3 className="hastag">#PerbanyakLiterasiCerdaskanGenerasi</h3>
          <div className="box">
            <p className="hastag">
            Copyright by  &copy; <span>Aditya Rizky</span> 
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
