import React from "react";
import { useEffect } from "react";
import { useParams } from "react-router-dom";
import { useState } from "react";
import { Link } from "react-router-dom";
import { apiHandler } from "../Api/apiHandler";

export default function ItemDetail() {
  const [data, setData] = useState();
  const { id } = useParams();

  useEffect(() => {
    apiHandler.find(id).then((response) => setData(response.data));
  }, []);

  if (!data) return <p>Loading..</p>;
  return (
    <div className="container-glass">
      <center>

      <div className="item-glass">
        <div className="card-glass">
          <img src={data.image} alt="" style={{ width: "450px" }} />
          <div className="destinasi-info">
            <h1 className="destinasi-title" style={{color: "black"}}>{data.nama}</h1>
            <h3 style={{color: "black"}}>{data.judul}</h3>
            <p className="destinasi-title2" style={{color: "black"}}>{data.desc}</p>
          </div>
          <div className="back-detail">
            <Link className="btn-delete" to={"/#destinasi"}>
             <button className="klik">
              Kembali
              </button> 
              
            </Link>
          </div>
        </div>
      </div>
      </center>
    </div>
  );
}
