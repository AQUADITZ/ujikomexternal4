import React from 'react'
import { useEffect } from 'react'
import loginHandler from '../Api/LoginHandler'
import { useState } from 'react'
import { useRef } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Login() {
    const [data, setData] = useState()
    const formRef = useRef()
    const navigate = useNavigate();
    useEffect(() => {
        loginHandler.get().then(result => setData(result))
    }, [])
    function submit(e) {
        e.preventDefault();
        // if (checkUser) return alert("Anda telah login!");
        const { [0]: username, [1]: password } = formRef.current;

        if (username.value.length <= 0 || password.value.length <= 0) return alert("Masukkan data");

        const matchUsername = data.find((i) => i.username == username.value);
        const matchPassword = matchUsername?.password == password.value;

        if (matchUsername && matchPassword) {
            console.log("test")
            localStorage.setItem("username", username.value);
            navigate("/");
            window.location.reload();
        } else {
            return alert("akun tidak ada");
        }

    }
    return (
        <div className='login'>
            <center>
            <form className='login2' ref={formRef}>
                <input type="text" placeholder='Masukkan Username' />
                <input type="password" placeholder='Masukkan Password' />
                <button onClick={submit}>Submit</button>
            </form>
            </center>
        </div>
    )
}
