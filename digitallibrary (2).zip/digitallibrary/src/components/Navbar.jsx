import React from "react";

export default function Navbar() {
  const username = localStorage.getItem("username")
  return (
    <div className="navbar">
      <div className="container">
        <div className="box-navbar">
          <div className="gambar-2">
          <img className="gambar-atas" src="logoanak.png" alt="" />        
          <h1>D-LIBRARY</h1>
          </div>
         
          
          <ul className="menu">
            <li className="active">
              <a href="/#home">Home</a>
            </li>
            <li className="active">
              <a href="/#buku">Buku</a>
            </li>
            <li className="active">
              <a href="/#services">Ulasan</a>
            </li>
            <li className="active">
              <a href="/#daftar">Layanan</a>
            </li>
            {username ?
             
                <li className="active2">
                  <a className="active3" href="/logout">LOG OUT</a>
                </li>
            
              : <li className="active2">
                <a className="active3" href="/login">LOG IN</a>
              </li>}
          </ul>
          <i className="fa-solid fa-bars menu-bar"></i>
        </div>
      </div>
    </div>
  );
}
